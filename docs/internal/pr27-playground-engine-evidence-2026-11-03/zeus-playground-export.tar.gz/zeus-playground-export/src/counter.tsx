import { createSignal } from '@zeus-js/zeus'

export const Counter = () => {
  const [count, setCount] = createSignal(0)
  return (
    <button onClick={() => setCount(count() + 1)}>
      Live: {count()}
    </button>
  )
}
