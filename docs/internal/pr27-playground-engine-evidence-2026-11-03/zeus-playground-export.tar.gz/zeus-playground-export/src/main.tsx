import { render } from '@zeus-js/zeus'
import { Counter } from './counter'
import './counter.css'

render(() => <Counter />, document.querySelector('#root')!)
