import { render } from '@zeus-js/zeus'
import * as Entry from './main'

type Component = () => unknown

const root = document.querySelector('#root')
if (!(root instanceof Element)) {
  throw new Error('Zeus playground export requires a #root element.')
}

// Entry modules that already call render() populate #root during import.
if (root.childNodes.length === 0) {
  const entries = Entry as Record<string, unknown>
  const component =
    [entries.default, entries.App, entries.Counter].find(
      (value): value is Component => typeof value === 'function',
    ) ??
    Object.values(entries).find(
      (value): value is Component => typeof value === 'function',
    )
  if (!component) {
    throw new Error(
      'The exported entry must default-export a component, export a component, or call render().',
    )
  }
  render(component as () => any, root)
}
