# zeus-playground-export

Exported from the Zeus playground.

This project preserves the original 3-file source snapshot,
uses `wasm:0.1.1-beta.20` as its recorded compiler version, and targets
`native`.

```sh
pnpm install --ignore-scripts
pnpm check
pnpm build
pnpm dev
```

The generated entry auto-mounts a component when the source itself does not
call `render()`.
